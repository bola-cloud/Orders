<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TrackDeliverymanController extends Controller
{
    //
}
